'use client'

/**
 * REDIRECIONAMENTO PARA GERADOR OTIMIZADO v3.0
 * Este arquivo agora é apenas um wrapper para o OptimizedCodeGenerator
 * Mantém compatibilidade com código existente
 */

import OptimizedCodeGenerator from './OptimizedCodeGenerator'

export default OptimizedCodeGenerator
