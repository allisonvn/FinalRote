// Redirect to professional experiments page (most advanced version)
export { default } from './professional-page'